#ifndef NDEBUG
#include <vld.h> // Visual Leak Detector, �til en modo Debug para detectar fugas de memoria
#endif

#include "raylib.h"

int main(void)
{
    // Inicializamos una ventana de 800x450 p�xeles con un t�tulo personalizado
    InitWindow(800, 450, "Trabajo Practico 1, Tomas Malisani");

    // Configuramos el framerate deseado (opcional, pero recomendado)
    SetTargetFPS(60);

    Color fondo = BLACK;
    Color texto = WHITE;

    Color texto_Secundario = WHITE;
    bool esta_Azul=false;
    // Bucle principal del juego (se repite hasta que se cierre la ventana)
    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(fondo);
        //Texto Principal
        DrawText("Tomas Fernando Malisani :D", 255, 200, 20, texto);
        //Texto Secundario
        DrawText("Apreta espacio para cambiarme de color :O", 185, 300, 20, texto_Secundario);
        if (IsKeyPressed(KEY_SPACE) && esta_Azul==false) 
        {
            texto_Secundario = BLUE;
            esta_Azul = true;
        }
        else if (IsKeyPressed(KEY_SPACE) && esta_Azul == true) 
        {
            texto_Secundario = WHITE;
			esta_Azul = false;
        }
        DrawRectangle(200, 190, 400, 40, Fade(DARKBLUE, 0.2f));
        EndDrawing();
    }
    CloseWindow();

    return 0;
}

