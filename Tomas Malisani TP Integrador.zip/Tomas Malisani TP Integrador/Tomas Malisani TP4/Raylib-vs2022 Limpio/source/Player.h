#ifndef PLAYER_H
#define PLAYER_H

#ifndef NDEBUG
#include <vld.h>
#endif

#include "raylib.h"

struct Player
{
    Texture2D texture;

    Vector2 spawn;
    Vector2 position;

    float scale;
    float speed;

    float jumpSpeed;
    float jumpDistance;
    bool isJumping;
    float jumpRemaining;

    Player();
    ~Player();

    // Inicializa recursos y valores del personaje (sin sonido)
    void Init(const char* texturePath, Vector2 spawnPos,float scale = 0.15f, float speed = 3.5f,float jumpSpeed = 8.0f, float jumpDistance = 100.0f);

    void Update(const Rectangle* groundRects, int groundCount);


    void Draw() const;
    Vector2 GetPosition() const;


    float GetScale() const;
    float GetWidthScaled() const;
    float GetHeightScaled() const;
    void ResetPosition();


    void Unload();
};

#endif 