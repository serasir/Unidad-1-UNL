#ifndef NDEBUG
#include <vld.h> 
#endif

#include "raylib.h"
#include "Player.h"
#include "Floor.h"
#include "Enemy.h"

int main(void)
{
    InitWindow(800, 600, "TP INTEGRADOR - Tomas Malisani");
    SetTargetFPS(60);

    Color fondo = BLACK;
    Texture2D fondoTexture = LoadTexture("Fondo.png");



    Player player;
    player.Init("Sora2D.png", {100.0f, 250.0f}, 0.15f, 3.5f, 8.0f, 100.0f);




    // crear Array de los suelos
    const int floorCount = 4;
    Floor floors[floorCount];

    Vector2 spawn = player.GetPosition();
    float playerH = player.GetHeightScaled();

    // Bloque abajo del personaje
    floors[0].Init("Floor.png", { spawn.x, spawn.y + playerH }, 0.10f);

    // INICIAR LOS 3 BLOQUES
    floors[1].Init("Floor.png", { spawn.x + 180.0f, spawn.y + playerH - 40.0f }, 0.10f);
    floors[2].Init("Floor.png", { spawn.x + 360.0f, spawn.y + playerH + 20.0f }, 0.10f); 
    floors[3].Init("Floor.png", { spawn.x + 540.0f, spawn.y + playerH - 80.0f }, 0.10f); 

    // ENEMIGO 
    Enemy enemy;
    {
        enemy.Init("Floor.png", { 500.0f, 210.0f }, 0.05f, 1.5f); 
        
        enemy.SetOrigin(500.0f);
        
        //MAXIMO RECORRIDO
        enemy.SetTravelLimit(80.0f);       
    }

    //MENU (Iniciar, Cerrar y titulo), PLAYING (juego)
    enum GameState { MENU, PLAYING };
    GameState state = MENU;

    // Botones
    Rectangle buttonStart = { (800 - 220) / 2.0f, 220.0f, 220, 64 };
    Rectangle buttonClose  = { (800 - 220) / 2.0f, 320.0f, 220, 64 };

  
    bool paused = false;
    bool won = false;
    bool lost = false;

    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(fondo);

        Vector2 mousePos = GetMousePosition();
        bool mouseClicked = IsMouseButtonPressed(MOUSE_LEFT_BUTTON);

        if (state == MENU)
        {
            //Fondo para el MENU y el titulo
            DrawRectangle(0, 0, 800, 600, DARKGRAY);
            DrawText("UNL TP Integrador", 280, 120, 30, RAYWHITE);

            // Start button
            Color startColor = CheckCollisionPointRec(mousePos, buttonStart) ? LIGHTGRAY : GRAY;
            DrawRectangleRec(buttonStart, startColor);
            DrawText("INICIAR", 355,240, 24, BLACK);

            // Exit button
            Color exitColor = CheckCollisionPointRec(mousePos, buttonClose) ? LIGHTGRAY : GRAY;
            DrawRectangleRec(buttonClose, exitColor);
            DrawText("CERRAR", 355, 340, 24, BLACK);

            // Click en INICIAR
            if (mouseClicked && CheckCollisionPointRec(mousePos, buttonStart))
            {
                state = PLAYING;
                paused = false; 
                won = false; 
                lost = false;
                player.ResetPosition();
                enemy.position.x = 500.0f;
                enemy.position.y = 210.0f;
                enemy.SetOrigin(500.0f);
            }
			//Click en CERRAR
            else if (mouseClicked && CheckCollisionPointRec(mousePos, buttonClose))
            {
                player.Unload();
                enemy.Unload();
                for (int i = 0; i < floorCount; ++i) floors[i].Unload();
                CloseWindow();
                return 0;
            }
        }
        else // Iniciar partida
        {
            DrawTexture(fondoTexture, 0, 0, WHITE);

            Rectangle floorRects[floorCount];
            for (int i = 0; i < floorCount; ++i)
            {
                floorRects[i] = floors[i].GetCollisionRect();
            }

            if (!paused)
            {
                player.Update(floorRects, floorCount);
                enemy.Update();
            }

            // Dibuja los suelos en bucle para asi el ultimo cambiarle el color
            for (int i = 0; i < floorCount; ++i)
            {
                if (i == 3)
                {
                    DrawTextureEx(floors[i].texture, floors[i].position, 0.0f, floors[i].scale, GOLD);
                }
                else
                {
                    floors[i].Draw();
                }
            }
            enemy.Draw();
            player.Draw();

            // CHEQUEAR CONDICIONES DE VICTORIA Y DERROTA
            if (!won && !lost)
            {
                Vector2 pos = player.GetPosition();
                Rectangle playerRect = { pos.x, pos.y, player.GetWidthScaled(), player.GetHeightScaled() };

                // Si llega al ultimo cubo GANASTE
                if (pos.y >= 170 && pos.x >= 600.0f && pos.x <= 670.0f)
                {
                    won = true;
                    paused = true;
                }

                // Caida al vacio
                if (pos.y > 600.0f)
                {
                    lost = true;
                    paused = true;
                }

                // Checkear si se cchoca con el enemigo
                Rectangle enemyRect = enemy.GetCollisionRect();
                if (CheckCollisionRecs(playerRect, enemyRect))
                {
                    lost = true;
                    paused = true;
                }
            }

            // Posicion del personaje
              Vector2 pos = player.GetPosition();
              DrawText(TextFormat("Posicion X= %.0f", pos.x), 10, 10, 20, WHITE);
              DrawText(TextFormat("Posicion Y= %.0f", pos.y), 10, 40, 20, WHITE);
            

            // Mensajes PERDISTE o Ganaste
            if (won)
            {
                DrawText("GANASTE", 300, 260, 40, GREEN);
                DrawText("Presiona R para reiniciar", 300, 320, 20, WHITE);
            }
            else if (lost)
            {   
                DrawText("PERDISTE",300, 260, 40, RED); 
                DrawText("Presiona R para reiniciar", 300, 320, 20, WHITE);
            }

            // Reiniciar TODO con R
            if (IsKeyPressed(KEY_R))
            {
                player.ResetPosition();
                enemy.position.x = 500.0f;
                enemy.position.y = 210.0f;
                enemy.SetOrigin(500.0f);

                paused = false;
                won = false;
                lost = false;
            }
        }
        EndDrawing();
    }

    player.Unload();
    enemy.Unload();
    for (int i = 0; i < floorCount; ++i) floors[i].Unload();

    CloseWindow();

    return 0;
}

