#ifndef NDEBUG
#include <vld.h>
#endif

#include "Enemy.h"

Enemy::Enemy() : texture(), position{ 0.0f, 0.0f }, scale(1.0f), speed(0.0f), originX(0.0f), travelLimit(50.0f), traveled(0.0f), direction(-1) {}

Enemy::~Enemy()
{
    Unload();
}

void Enemy::Init(const char* texturePath, Vector2 pos, float _scale, float _speed)
{
    texture = LoadTexture(texturePath);
    position = pos;
    scale = _scale;
    speed = _speed;

    // Datos del movimiento
    originX = pos.x;
    travelLimit = 80.0f;
    traveled = 0.0f;
    direction = -1; 
}

void Enemy::Update()
{
    position.x += direction * speed;
    traveled += speed;

    if (traveled >= travelLimit)
    {
        float overshoot = traveled - travelLimit;
        if (overshoot > 0.0f)
        {
            // mover en sentido contrario
            position.x -= direction * overshoot;
        }

        // Cambiar direcci�n y reiniciar contador
        direction = -direction;
        traveled = 0.0f;
    }
}


//Al ser la misma textura que el suelo, se pinta de rojo para dejar en claro que es enemigo
void Enemy::Draw() const
{
    DrawTextureEx(texture, position, 0.0f, scale, RED);
}

Rectangle Enemy::GetCollisionRect() const
{
    return Rectangle
    {
        position.x,
        position.y,
        static_cast<float>(texture.width) * scale,
        static_cast<float>(texture.height) * scale
    };
}

void Enemy::Unload()
{
    if (texture.id != 0)
    {
        UnloadTexture(texture);
    }
    texture = {};
}