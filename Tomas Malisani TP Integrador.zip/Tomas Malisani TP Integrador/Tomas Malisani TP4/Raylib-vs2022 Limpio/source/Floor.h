#ifndef FLOOR_H
#define FLOOR_H

#ifndef NDEBUG
#include <vld.h>
#endif

#include "raylib.h"

struct Floor
{
    Texture2D texture;
    Vector2 position;
    float scale;

    Floor();
    ~Floor();

    void Init(const char* texturePath, Vector2 pos, float scale = 0.10f);
    void Draw() const;
    Rectangle GetCollisionRect() const;
    void Unload();
};

#endif 