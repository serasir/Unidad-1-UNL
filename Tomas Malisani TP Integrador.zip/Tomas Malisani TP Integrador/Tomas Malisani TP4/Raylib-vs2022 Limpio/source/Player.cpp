#ifndef NDEBUG
#include <vld.h> 
#endif

#include "Player.h"

Player::Player():texture(),spawn{0.0f, 0.0f}, position{0.0f, 0.0f},scale(1.0f), speed(0.0f),jumpSpeed(0.0f), jumpDistance(0.0f),isJumping(false), jumpRemaining(0.0f){}

Player::~Player()
{
    Unload();
}

void Player::Init(const char* texturePath, Vector2 spawnPos,float _scale, float _speed, float _jumpSpeed, float _jumpDistance)
{
    texture = LoadTexture(texturePath);

    spawn = spawnPos;
    position = spawnPos;

    scale = _scale;
    speed = _speed;

    jumpSpeed = _jumpSpeed;
    jumpDistance = _jumpDistance;
    isJumping = false;
    jumpRemaining = 0.0f;
}

void Player::Update(const Rectangle* groundRects, int groundCount)
{
    // Cheuquear si esta sobre algun suelo
    auto checkOnGround = [&](const Vector2 &pos) -> bool {
        float playerLeft = pos.x;
        float playerRight = pos.x + GetWidthScaled();
        float playerBottom = pos.y + GetHeightScaled();

        for (int i = 0; i < groundCount; ++i)
        {
            const Rectangle &g = groundRects[i];
            float groundLeft = g.x;
            float groundRight = g.x + g.width;
            float groundTop = g.y;

            bool horizontalOverlap = (playerRight > groundLeft) && (playerLeft < groundRight);

            // Margen de error
            if (horizontalOverlap && (playerBottom >= groundTop - 2.0f) && (playerBottom <= groundTop + 10.0f))
            {
                return true;
            }
        }
        return false;
    };

    bool onGroundBefore = false;
    if (groundRects != nullptr && groundCount > 0)
        onGroundBefore = checkOnGround(position);

    // Movimiento horizontal
    if (IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT))
    {
        position.x += speed;
    }
    if (IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT))
    {
        position.x -= speed;
    }

    // Reiniciar posicion
    if (IsKeyDown(KEY_R))
    {
        ResetPosition();
    }

    // Espacio para saltar
    if (IsKeyPressed(KEY_SPACE) && !isJumping && onGroundBefore)
    {
        isJumping = true;
        jumpRemaining = jumpDistance;
    }

    // Bucle de salto
    if (isJumping)
    {
        float moveUp = jumpSpeed;
        if (moveUp > jumpRemaining) moveUp = jumpRemaining;
        position.y -= moveUp;
        jumpRemaining -= moveUp;
        if (jumpRemaining <= 0.0f) isJumping = false;
    }

    // Gravedad
    const float gravity = 4.0f;
    bool onGroundAfter = false;


    //Cheuquear si toca el suelo
    if (groundRects != nullptr && groundCount > 0)
    {
        float playerLeft = position.x;
        float playerRight = position.x + GetWidthScaled();
        float playerBottom = position.y + GetHeightScaled();

        for (int i = 0; i < groundCount; ++i)
        {
            const Rectangle &g = groundRects[i];
            float groundLeft = g.x;
            float groundRight = g.x + g.width;
            float groundTop = g.y;

            bool horizontalOverlap = (playerRight > groundLeft) && (playerLeft < groundRight);

            if (horizontalOverlap && (playerBottom >= groundTop - 2.0f) && (playerBottom <= groundTop + 20.0f))
            {
                position.y = groundTop - GetHeightScaled();
                onGroundAfter = true;
                isJumping = false;
                jumpRemaining = 0.0f;
                break;
            }
        }
    }

    //Gravedad si esta en el aire
    if (!onGroundAfter && !isJumping)
    {
        position.y += gravity;
    }
}

void Player::Draw() const
{
    DrawTextureEx(texture, position, 0.0f, scale, WHITE);
}

Vector2 Player::GetPosition() const
{
    return position;
}

float Player::GetScale() const
{
    return scale;
}

float Player::GetWidthScaled() const
{
    return static_cast<float>(texture.width) * scale;
}

float Player::GetHeightScaled() const
{
    return static_cast<float>(texture.height) * scale;
}

void Player::ResetPosition()
{
    position = spawn;
    isJumping = false;
    jumpRemaining = 0.0f;
}

void Player::Unload()
{
    if (texture.id != 0)
    {
        UnloadTexture(texture);
    }
    texture = {};
}