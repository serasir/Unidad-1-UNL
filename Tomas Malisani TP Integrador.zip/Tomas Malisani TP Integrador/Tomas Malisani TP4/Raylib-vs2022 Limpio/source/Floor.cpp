#ifndef NDEBUG
#include <vld.h>
#endif

#include "Floor.h"

Floor::Floor()
    : texture(), position{0.0f, 0.0f}, scale(1.0f)
{
}

Floor::~Floor()
{
    Unload();
}

void Floor::Init(const char* texturePath, Vector2 pos, float _Scale)
{
    texture = LoadTexture(texturePath);
    position = pos;
    scale = _Scale;
}

void Floor::Draw() const
{
    DrawTextureEx(texture, position, 0.0f, scale, WHITE);
}

Rectangle Floor::GetCollisionRect() const
{
    return Rectangle
    { position.x, position.y,
      static_cast<float>(texture.width) * scale ,
      static_cast<float>(texture.height) * scale  
    };
}

void Floor::Unload()
{
    if (texture.id != 0)
    {
        UnloadTexture(texture);
    }
    texture = {};
}