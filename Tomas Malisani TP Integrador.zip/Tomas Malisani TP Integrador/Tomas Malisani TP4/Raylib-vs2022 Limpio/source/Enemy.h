#ifndef ENEMY_H
#define ENEMY_H

#ifndef NDEBUG
#include <vld.h>
#endif

#include "raylib.h"

struct Enemy
{
    Texture2D texture;
    Vector2 position;
    float scale;
    float speed;

    // MOVIMIENTO DEL ENEMIGO
    float originX;        //Spawn
    float travelLimit;    // maximo de distancia, para cambiar desde el Main
    float traveled;       // para saber si ya llego al maximo
    int direction;        // -1 = izquierda, +1 = derecha

    Enemy();
    ~Enemy();

    void Init(const char* texturePath, Vector2 pos, float _scale = 0.10f, float _speed = 2.0f);
    void Update();
    void Draw() const;
    Rectangle GetCollisionRect() const;
    void Unload();

    // Ajustes runtime
    void SetOrigin(float x) { originX = x; traveled = 0.0f; direction = -1; position.x = x; }
    void SetTravelLimit(float limit) { travelLimit = limit; }
};

#endif 