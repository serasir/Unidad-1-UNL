#ifndef NDEBUG
#include <vld.h> // Visual Leak Detector, �til en modo Debug para detectar fugas de memoria
#endif

#include "raylib.h"

int main(void)
{
    InitWindow(800, 600, "Trabajo Practico 4 Tomas Malisani");
    InitAudioDevice();
    SetTargetFPS(60);
    Color fondo = BLACK;


    float Speed = 3.5f;


    //Movimiento de salto 
    float JumpSpeed = 8.0f;        
    float JumpDistance = 100.0f;   
    bool isJumping = false;
    float jumpRemaining = 0.0f;

    //Sonido Salto
	Sound JumpSound = LoadSound("Salto.mp3");


    //Character
    Texture2D MainCharacter = LoadTexture("Sora2D.png");

    //Posicion Inicial
    Vector2 CharacterSpawn = { 100.0f, 250.0f };

    //Posicion que se va a mover
    Vector2 CharacterPosition = { 100.0f,250.0f };

	//Posicion y Radio del Circulo
	Vector2 CirclePosition = { 400.0f, 50.0f };
	float CircleRadius = 50.0f;


    //Bool para chequear si apretaste M para ver el mensaje
	bool ShowMessage = true;

    while (!WindowShouldClose())
    {

        BeginDrawing();
        ClearBackground(fondo);

        //OBTENER MOUSE
        Vector2 mousePos = GetMousePosition();

		//CHEQUEAR SI EL MOUSE ESTA DENTRO DEL CIRCULO
        bool mouseInside = CheckCollisionPointCircle(mousePos, CirclePosition, CircleRadius);




		DrawTextureEx(MainCharacter, (CharacterPosition), 0.0f, 0.35f, WHITE);
        DrawCircle(CirclePosition.x,CirclePosition.y, CircleRadius, WHITE);
		DrawText("BOTON", 365, 40, 20, BLACK);


        //TEXTO INFORMACION
        if (ShowMessage == true) 
        {
            DrawText(TextFormat("Posicion X= %.0f", CharacterPosition.x), 10, 10, 20, WHITE);
            DrawText(TextFormat("Posicion Y= %.0f", CharacterPosition.y), 10, 40, 20, WHITE);
        }


		//Presionar M para mostrar/ocultar el mensaje   
        if (IsKeyPressed(KEY_M)) 
        {
            if (ShowMessage == true) 
            {
                ShowMessage = false;
            }
            else 
            {
				ShowMessage = true;
            }
        }
        //Reiniciar posicion
        if (IsKeyDown(KEY_R)) 
        {
            CharacterPosition = CharacterSpawn;
        }

        //Movimiento
        if (IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT)) 
        {
            CharacterPosition.x += Speed;
        }
        if (IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT))
        {
            CharacterPosition.x -= Speed;
        }

        //Click

        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && mouseInside) 
        {
            fondo = RED;
        }


        // Activar Salto con el espacio
        if (IsKeyPressed(KEY_SPACE) && !isJumping)
        {
            isJumping = true;
            jumpRemaining = JumpDistance;
			PlaySound(JumpSound);
        }

        // Bucle de salto hasta que se vuelva falso
        if (isJumping)
        {
            float move = JumpSpeed;
            if (move > jumpRemaining) 
            {
                move = jumpRemaining;
            }
            CharacterPosition.y -= move; 
            jumpRemaining -= move;
            if (jumpRemaining <= 0.0f) 
            {
				isJumping = false;
            } 
        }



        EndDrawing();
    }

    CloseWindow();

    return 0;
}

