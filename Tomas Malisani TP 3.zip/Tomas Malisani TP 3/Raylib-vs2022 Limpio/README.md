<div align="center">

# Raylib Visual Studio 2022 Template

[![Raylib](https://img.shields.io/badge/Raylib-4.2.0-1864ab?style=flat-square&labelColor=212529)](https://www.raylib.com/)
[![Visual Studio 2022](https://img.shields.io/badge/Visual%20Studio-2022-1864ab?style=flat-square&logo=Visual%20Studio&logoColor=white&labelColor=212529)](https://visualstudio.microsoft.com/vs/)
[![C++](https://img.shields.io/badge/C++-17%2B-1864ab?style=flat-square&logo=C%2B%2B&logoColor=white&labelColor=212529)](https://isocpp.org/)
[![MIT License](https://img.shields.io/badge/License-MIT-1864ab?style=flat-square&logo=open-source-initiative&logoColor=white&labelColor=212529)](https://opensource.org/licenses/MIT)

This repository contains a Visual Studio 2022 project file template for the simple and easy-to-use game programming library, Raylib. The project file is portable, allowing you to quickly set up a new Raylib project in Visual Studio on any machine.

</div>
