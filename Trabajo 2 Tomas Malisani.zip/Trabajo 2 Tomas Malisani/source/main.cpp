#ifndef NDEBUG
#include <vld.h> // Visual Leak Detector, �til en modo Debug para detectar fugas de memoria
#endif

#include "raylib.h"

int main(void)
{
    // Resolucion de la ventana 
    InitWindow(1024, 768, "Tomas Malisani Trabajo 2");

    SetTargetFPS(60);

    bool isWhite = true;
    Color fondo = {BLACK};
    Color Circulo_Color = Fade(WHITE, 0.2f);

    int Cantidad_Rebotes = 0;
    int Velocidad = 5;
    Vector2 Posicion_Circulo = {512,384};
    while (!WindowShouldClose())
    {
		float deltaTime = GetFrameTime();
        BeginDrawing();

        ClearBackground(fondo);

		//Texto que muestra las coordenadas del circulo
        //Posicion X
        DrawText(TextFormat("Posicion X= %.0f", Posicion_Circulo.x), 10, 10, 20, WHITE);
        //Posicion Y
        DrawText(TextFormat("Posicion Y= %.0f", Posicion_Circulo.y), 10, 50, 20, WHITE);

        //Mostrar rebotes
		DrawText(TextFormat("Cantidad de Rebotes= %i", Cantidad_Rebotes), 10, 90, 20, WHITE);

        //Dibujo del circulo en el centro de la pantalla y con el color definido anteriormente
		DrawCircle(Posicion_Circulo.x, Posicion_Circulo.y, 100,Circulo_Color);

        //Rebota al chocar en el borde de la ventana en X y cambio de color
        if (Posicion_Circulo.x >= 925 && isWhite==true) 
        {
                Circulo_Color = Fade(RED, 0.2f);
                Posicion_Circulo.x -= Velocidad * 8;
                isWhite = false;
				Cantidad_Rebotes++;
        }
        else if (Posicion_Circulo.x >= 925 && isWhite == false)
        {
            Circulo_Color = Fade(WHITE, 0.2f);
            Posicion_Circulo.x -= Velocidad * 8;
            isWhite = true;
			Cantidad_Rebotes++;
        }



        if (Posicion_Circulo.x <= 100 && isWhite==true) 
        {
            Posicion_Circulo.x += Velocidad*8;
            Circulo_Color = Fade(RED, 0.2f);
			isWhite = false;
			Cantidad_Rebotes++;
		}
        else if (Posicion_Circulo.x <= 100 && isWhite == false) 
        {
            Posicion_Circulo.x += Velocidad * 8;
            Circulo_Color = Fade(WHITE, 0.2f);
            isWhite = true;
            Cantidad_Rebotes++;
        }

		//Rebota al chocar en el borde de la ventana en Y y cambio de color
        if (Posicion_Circulo.y <= 100 && isWhite == true) 
        {
            Posicion_Circulo.y += Velocidad * 8;
            Circulo_Color = Fade(RED, 0.2f);
            isWhite = false;
            Cantidad_Rebotes++;
        }
        else if (Posicion_Circulo.y <= 100 && isWhite == false) 
        {
            Posicion_Circulo.y += Velocidad * 8;
            Circulo_Color = Fade(WHITE, 0.2f);
            isWhite = true;
            Cantidad_Rebotes++;
        }


        if (Posicion_Circulo.y >= 624 && isWhite == true)
        {
            Posicion_Circulo.y -= Velocidad * 8;
            Circulo_Color = Fade(RED, 0.2f);
            isWhite = false;
            Cantidad_Rebotes++;
        }
        else if (Posicion_Circulo.y >= 624 && isWhite == false)
        {
            Posicion_Circulo.y -= Velocidad * 8;
            Circulo_Color = Fade(WHITE, 0.2f);
            isWhite = true;
            Cantidad_Rebotes++;
        }



        //Movimiento
        //Derecha e Izquierda
        if (IsKeyDown(KEY_D))
        {
			Posicion_Circulo.x += Velocidad*deltaTime*60;
        }
        else if (IsKeyDown(KEY_A)) 
        {
			Posicion_Circulo.x -= Velocidad*deltaTime*60;
        }

        //Arriba y Abajo
        if (IsKeyDown(KEY_W)) 
        {
            Posicion_Circulo.y -= Velocidad*deltaTime*60;
        }
        else if (IsKeyDown(KEY_S)) 
		{
			Posicion_Circulo.y += Velocidad*deltaTime*60;
        }


        // Finalizamos el dibujo
        EndDrawing();
    }
    // Cerramos la ventana y liberamos recursos
    CloseWindow();

    return 0;
}

